This function is by Frederic Moisy. NO BSD License.
See MATLAB Central: http://www.mathworks.com/matlabcentral/fileexchange/12770-myginput

The following changes were made to the original file by the authors of DIPUM3E:

Modified Line 37 on 12/19/2014 

FROM:

strpointertype='fullcrosshair'; % default GINPUT pointer

TO:

strpointertype='crosshair'; % default GINPUT pointer

BECAUSE: 'fullcrosshair' is no longer a supported option in MATLAB.
